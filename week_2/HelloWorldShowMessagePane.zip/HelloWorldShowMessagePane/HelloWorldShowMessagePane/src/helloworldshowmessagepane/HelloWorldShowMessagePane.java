package helloworldshowmessagepane;
// 0 :: Import JOptionPane
import javax.swing.JOptionPane;

public class HelloWorldShowMessagePane {
/*
* The programs purpose To Display dialog box with message “hello World”
* Programmer: Student - Christian Alvarez
*/

    public static void main(String[] args) {
        /*Prompts*/
        // 1 :: Output "hello World" & " Hello Wright College"
        JOptionPane.showMessageDialog(null, "Hello World");
        JOptionPane.showMessageDialog(null, "Hello Wright College");
        JOptionPane.showMessageDialog(null, "Hello My Name is Christian Alvarez");
    }
    
}
